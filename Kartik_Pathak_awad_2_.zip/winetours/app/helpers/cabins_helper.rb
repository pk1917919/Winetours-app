module CabinsHelper
end
