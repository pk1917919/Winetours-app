module CruisesHelper
end
