class Cruise < ApplicationRecord
  belongs_to :ship
end
