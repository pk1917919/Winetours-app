class Winetour < ApplicationRecord
end
