class Ship < ApplicationRecord
end
