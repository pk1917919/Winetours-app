class Harbour < ApplicationRecord
end
