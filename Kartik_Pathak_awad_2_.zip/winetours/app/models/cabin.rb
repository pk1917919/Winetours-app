class Cabin < ApplicationRecord
  belongs_to :ship
end
