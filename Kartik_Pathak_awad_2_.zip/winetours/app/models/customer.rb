class Customer < ApplicationRecord
  belongs_to :winetours
end
