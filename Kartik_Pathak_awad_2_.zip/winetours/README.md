# README

Please use the List of Commands file to see the development of the winetours application

I have an error with the rake db:migrate whihc is causing a pending migrations error,
I have tried db:rollback without any success.




Things you may want to cover:

* Ruby version          2.5.2

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
# Winetours-app
