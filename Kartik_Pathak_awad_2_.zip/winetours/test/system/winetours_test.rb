require "application_system_test_case"

class WinetoursTest < ApplicationSystemTestCase
  setup do
    @winetour = winetours(:one)
  end

  test "visiting the index" do
    visit winetours_url
    assert_selector "h1", text: "Winetours"
  end

  test "creating a Winetour" do
    visit winetours_url
    click_on "New Winetour"

    fill_in "Name", with: @winetour.name
    fill_in "Wineyard", with: @winetour.wineyard
    click_on "Create Winetour"

    assert_text "Winetour was successfully created"
    click_on "Back"
  end

  test "updating a Winetour" do
    visit winetours_url
    click_on "Edit", match: :first

    fill_in "Name", with: @winetour.name
    fill_in "Wineyard", with: @winetour.wineyard
    click_on "Update Winetour"

    assert_text "Winetour was successfully updated"
    click_on "Back"
  end

  test "destroying a Winetour" do
    visit winetours_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Winetour was successfully destroyed"
  end
end
