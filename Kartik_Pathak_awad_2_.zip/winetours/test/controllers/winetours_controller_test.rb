require 'test_helper'

class WinetoursControllerTest < ActionDispatch::IntegrationTest
  setup do
    @winetour = winetours(:one)
  end

  test "should get index" do
    get winetours_url
    assert_response :success
  end

  test "should get new" do
    get new_winetour_url
    assert_response :success
  end

  test "should create winetour" do
    assert_difference('Winetour.count') do
      post winetours_url, params: { winetour: { name: @winetour.name, wineyard: @winetour.wineyard } }
    end

    assert_redirected_to winetour_url(Winetour.last)
  end

  test "should show winetour" do
    get winetour_url(@winetour)
    assert_response :success
  end

  test "should get edit" do
    get edit_winetour_url(@winetour)
    assert_response :success
  end

  test "should update winetour" do
    patch winetour_url(@winetour), params: { winetour: { name: @winetour.name, wineyard: @winetour.wineyard } }
    assert_redirected_to winetour_url(@winetour)
  end

  test "should destroy winetour" do
    assert_difference('Winetour.count', -1) do
      delete winetour_url(@winetour)
    end

    assert_redirected_to winetours_url
  end
end
