require 'test_helper'

class CabinTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
